<?php
// This file is a part of GIII (g3.steelwap.org)
header('Content-Type: application/xhtml+xml;charset=utf-8');
header('Cache-Control: no-cache, must-revalidate');
?>